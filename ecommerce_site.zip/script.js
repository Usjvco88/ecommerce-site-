let currentLang = "ar";

const translations = {
  en: {
    home_title: "Welcome to Our Store",
    home_welcome: "Shop the best products at great prices!",
    nav_home: "Home",
    nav_products: "Products",
    products_title: "Products",
    product_1_name: "Shirt",
    product_1_desc: "Comfortable cotton shirt",
    product_2_name: "Shoes",
    product_2_desc: "High-quality sports shoes",
    buy: "Buy"
  },
  ar: {
    home_title: "مرحبا بكم في متجرنا",
    home_welcome: "تسوق أفضل المنتجات بأسعار رائعة!",
    nav_home: "الرئيسية",
    nav_products: "المنتجات",
    products_title: "المنتجات",
    product_1_name: "قميص",
    product_1_desc: "قميص قطني مريح",
    product_2_name: "حذاء",
    product_2_desc: "حذاء رياضي عالي الجودة",
    buy: "شراء"
  }
};

function toggleLanguage() {
  currentLang = currentLang === "ar" ? "en" : "ar";
  document.body.style.direction = currentLang === "ar" ? "rtl" : "ltr";
  document.body.style.textAlign = currentLang === "ar" ? "right" : "left";

  document.querySelectorAll("[data-lang]").forEach((el) => {
    const key = el.getAttribute("data-lang");
    if (translations[currentLang][key]) {
      el.textContent = translations[currentLang][key];
    }
  });
}